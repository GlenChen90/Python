from setuptools import setup

setup(
    name='plane',
    version='1.00',
    packages=[''],
    url='',
    license='',
    author='Glen',
    author_email='',
    description='plane'
)
